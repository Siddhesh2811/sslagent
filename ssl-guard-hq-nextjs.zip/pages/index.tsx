import Index from '../../src/pages/Index';
export default Index;
